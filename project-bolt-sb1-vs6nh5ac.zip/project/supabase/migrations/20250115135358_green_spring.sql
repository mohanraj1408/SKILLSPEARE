/*
  # Initial Schema Setup for Skillspeare

  1. New Tables
    - `profiles`
      - Stores user profile information for both students and mentors
      - Links to Supabase auth.users
      - Includes role (student/mentor), name, avatar, bio
    
    - `mentor_profiles`
      - Additional mentor-specific information
      - Hourly rate, availability, verification status
    
    - `skills`
      - Available skills/topics that can be taught
      - Categories and descriptions
    
    - `mentor_skills`
      - Junction table linking mentors to their skills
      - Includes proficiency level and verification status
    
    - `reviews`
      - Student reviews for mentors
      - Rating and feedback
    
    - `messages`
      - Chat messages between students and mentors
    
  2. Security
    - Enable RLS on all tables
    - Policies for appropriate access control
*/

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  role text NOT NULL CHECK (role IN ('student', 'mentor')),
  full_name text NOT NULL,
  avatar_url text,
  bio text,
  location text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create mentor_profiles table
CREATE TABLE mentor_profiles (
  id uuid PRIMARY KEY REFERENCES profiles(id),
  hourly_rate integer NOT NULL DEFAULT 0,
  availability jsonb DEFAULT '{"weekdays": true, "weekends": false, "hours": []}'::jsonb,
  is_verified boolean DEFAULT false,
  teaching_mode text DEFAULT 'online' CHECK (teaching_mode IN ('online', 'both')),
  total_students integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create skills table
CREATE TABLE skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  category text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create mentor_skills table
CREATE TABLE mentor_skills (
  mentor_id uuid REFERENCES mentor_profiles(id),
  skill_id uuid REFERENCES skills(id),
  proficiency_level integer CHECK (proficiency_level BETWEEN 1 AND 5),
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (mentor_id, skill_id)
);

-- Create reviews table
CREATE TABLE reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES profiles(id),
  mentor_id uuid REFERENCES mentor_profiles(id),
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create messages table
CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES profiles(id),
  receiver_id uuid REFERENCES profiles(id),
  content text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE mentor_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE mentor_skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public profiles are viewable by everyone" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Mentor profiles are viewable by everyone" ON mentor_profiles
  FOR SELECT USING (true);

CREATE POLICY "Mentors can update own profile" ON mentor_profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Skills are viewable by everyone" ON skills
  FOR SELECT USING (true);

CREATE POLICY "Mentor skills are viewable by everyone" ON mentor_skills
  FOR SELECT USING (true);

CREATE POLICY "Reviews are viewable by everyone" ON reviews
  FOR SELECT USING (true);

CREATE POLICY "Students can create reviews" ON reviews
  FOR INSERT WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Messages are viewable by participants" ON messages
  FOR SELECT USING (
    auth.uid() = sender_id OR 
    auth.uid() = receiver_id
  );

CREATE POLICY "Users can send messages" ON messages
  FOR INSERT WITH CHECK (auth.uid() = sender_id);