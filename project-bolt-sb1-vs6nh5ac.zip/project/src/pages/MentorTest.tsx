import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Clock } from 'lucide-react';

interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
}

const sampleQuestions: Question[] = [
  {
    id: 1,
    text: "Which of the following is NOT a valid way to declare a variable in JavaScript?",
    options: ["let x = 5;", "const y = 10;", "var z = 15;", "string w = 20;"],
    correctAnswer: 3
  },
  {
    id: 2,
    text: "What is the primary purpose of React's useEffect hook?",
    options: [
      "To handle side effects in functional components",
      "To create new components",
      "To style components",
      "To handle routing"
    ],
    correctAnswer: 0
  }
];

const MentorTest = () => {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers, answerIndex];
    setAnswers(newAnswers);

    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      // Test completed
      const score = newAnswers.reduce((acc, curr, idx) => 
        curr === sampleQuestions[idx].correctAnswer ? acc + 1 : acc, 0);
      
      if (score >= sampleQuestions.length * 0.7) {
        navigate('/profile/me');
      }
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-white shadow-lg rounded-lg p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Skill Assessment</h1>
          <div className="flex items-center text-gray-600">
            <Clock className="h-5 w-5 mr-2" />
            <span>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
          </div>
        </div>

        <div className="space-y-8">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-500">
              Question {currentQuestion + 1} of {sampleQuestions.length}
            </p>
            <div className="flex items-center space-x-1">
              {sampleQuestions.map((_, idx) => (
                <div
                  key={idx}
                  className={`h-2 w-8 rounded-full ${
                    idx < currentQuestion
                      ? 'bg-indigo-600'
                      : idx === currentQuestion
                      ? 'bg-indigo-200'
                      : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-medium text-gray-900 mb-6">
              {sampleQuestions[currentQuestion].text}
            </h2>

            <div className="space-y-4">
              {sampleQuestions[currentQuestion].options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(idx)}
                  className="w-full text-left p-4 rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50"
                >
                  <span className="font-medium">{option}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MentorTest;