import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Star, MapPin, Monitor } from 'lucide-react';

const mentors = [
  {
    id: 1,
    name: "Dr. Sarah Wilson",
    skill: "Data Science",
    rating: 4.9,
    reviews: 128,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    location: "New York, USA",
    mode: "Online/Offline",
    hourlyRate: 75,
    availability: "Weekdays",
    expertise: ["Python", "Machine Learning", "Statistics"]
  },
  {
    id: 2,
    name: "Prof. James Chen",
    skill: "Machine Learning",
    rating: 4.8,
    reviews: 95,
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    location: "San Francisco, USA",
    mode: "Online Only",
    hourlyRate: 85,
    availability: "Flexible",
    expertise: ["TensorFlow", "Deep Learning", "Computer Vision"]
  },
];

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  
  const filteredMentors = mentors.filter(mentor => 
    mentor.skill.toLowerCase().includes(query.toLowerCase()) ||
    mentor.expertise.some(skill => skill.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          Search Results for "{query}"
        </h1>
        <p className="text-gray-600 mt-2">
          Found {filteredMentors.length} mentors matching your search
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMentors.map((mentor) => (
          <Link
            key={mentor.id}
            to={`/profile/${mentor.id}`}
            className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105"
          >
            <div className="relative">
              <img
                src={mentor.image}
                alt={mentor.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full flex items-center space-x-1">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                <span className="text-sm font-medium">{mentor.rating}</span>
              </div>
            </div>

            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">{mentor.name}</h3>
              <p className="text-indigo-600 font-medium mb-4">{mentor.skill}</p>

              <div className="flex items-center space-x-4 text-gray-600 mb-4">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span className="text-sm">{mentor.location}</span>
                </div>
                <div className="flex items-center">
                  <Monitor className="h-4 w-4 mr-1" />
                  <span className="text-sm">{mentor.mode}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {mentor.expertise.map((skill) => (
                  <span
                    key={skill}
                    className="px-2 py-1 bg-indigo-100 text-indigo-600 rounded-full text-xs"
                  >
                    {skill}
                  </span>
                ))}
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <span className="text-lg font-bold text-gray-900">${mentor.hourlyRate}</span>
                  <span className="text-gray-500">/hour</span>
                </div>
                <span className="text-sm text-gray-500">{mentor.reviews} reviews</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default SearchResults;