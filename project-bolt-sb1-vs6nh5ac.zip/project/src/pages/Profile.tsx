import React from 'react';
import { useParams } from 'react-router-dom';
import { Star, MapPin, Monitor, Mail } from 'lucide-react';

const Profile = () => {
  const { id } = useParams();
  const isOwnProfile = id === 'me';

  const profile = {
    name: "Dr. Sarah Wilson",
    title: "Data Science Expert | Machine Learning Specialist",
    rating: 4.9,
    reviews: 128,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    location: "New York, USA",
    mode: "Online/Offline",
    bio: "Ph.D. in Computer Science with 8+ years of experience in Data Science and Machine Learning. Passionate about helping others learn and grow in the field.",
    skills: ["Python", "Machine Learning", "Data Analysis", "Deep Learning", "Statistics"],
    achievements: ["IBM Certified Data Scientist", "Stanford ML Certification", "500+ Students Mentored"]
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        {/* Cover Image */}
        <div className="h-48 bg-gradient-to-r from-indigo-500 to-purple-600" />
        
        {/* Profile Info */}
        <div className="relative px-6 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-end sm:space-x-6">
            <div className="-mt-24">
              <img
                src={profile.image}
                alt={profile.name}
                className="h-36 w-36 rounded-full border-4 border-white shadow-lg object-cover"
              />
            </div>
            
            <div className="mt-6 sm:mt-0 flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">{profile.name}</h1>
                  <p className="text-lg text-gray-600">{profile.title}</p>
                </div>
                {!isOwnProfile && (
                  <button className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 flex items-center">
                    <Mail className="h-5 w-5 mr-2" />
                    Message
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Stats & Info */}
        <div className="px-6 py-4 border-t border-gray-200">
          <div className="flex items-center space-x-6">
            <div className="flex items-center">
              <Star className="h-5 w-5 text-yellow-400" />
              <span className="ml-1 text-lg font-medium">{profile.rating}</span>
              <span className="ml-1 text-gray-500">({profile.reviews} reviews)</span>
            </div>
            <div className="flex items-center">
              <MapPin className="h-5 w-5 text-gray-500" />
              <span className="ml-1">{profile.location}</span>
            </div>
            <div className="flex items-center">
              <Monitor className="h-5 w-5 text-gray-500" />
              <span className="ml-1">{profile.mode}</span>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-6 py-8">
          {/* Bio Section */}
          <div className="md:col-span-2 space-y-6">
            <section>
              <h2 className="text-xl font-bold text-gray-900 mb-4">About</h2>
              <p className="text-gray-600">{profile.bio}</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-gray-900 mb-4">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </section>
          </div>

          {/* Achievements Section */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">Achievements</h2>
            <ul className="space-y-4">
              {profile.achievements.map((achievement) => (
                <li
                  key={achievement}
                  className="flex items-start"
                >
                  <Star className="h-5 w-5 text-yellow-400 mt-0.5 mr-2" />
                  <span className="text-gray-600">{achievement}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;