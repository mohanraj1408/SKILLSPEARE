import React from 'react';
import { Link } from 'react-router-dom';
import { Clock } from 'lucide-react';

const conversations = [
  {
    id: 1,
    mentor: {
      id: 'mentor1',
      name: 'Dr. Sarah Wilson',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
      skill: 'Data Science'
    },
    lastMessage: "Let's schedule your first session for next week.",
    timestamp: '2 hours ago',
    unread: true
  },
  {
    id: 2,
    mentor: {
      id: 'mentor2',
      name: 'Prof. James Chen',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
      skill: 'Machine Learning'
    },
    lastMessage: "Great progress on your last assignment!",
    timestamp: '1 day ago',
    unread: false
  }
];

const Messages = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
        </div>

        <div className="divide-y divide-gray-200">
          {conversations.map((conversation) => (
            <Link
              key={conversation.id}
              to={`/chat/${conversation.mentor.id}`}
              className="block hover:bg-gray-50 transition-colors"
            >
              <div className="px-6 py-4 flex items-center space-x-4">
                <div className="relative">
                  <img
                    src={conversation.mentor.image}
                    alt={conversation.mentor.name}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  {conversation.unread && (
                    <div className="absolute -top-1 -right-1 h-3 w-3 bg-indigo-600 rounded-full" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-medium text-gray-900 truncate">
                      {conversation.mentor.name}
                    </h2>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      {conversation.timestamp}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">{conversation.mentor.skill}</p>
                  <p className="text-sm text-gray-500 truncate">{conversation.lastMessage}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Messages;