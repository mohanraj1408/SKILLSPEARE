import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Send, Phone, Video } from 'lucide-react';

const Chat = () => {
  const { mentorId } = useParams();
  const [message, setMessage] = useState('');

  const mentor = {
    name: "Dr. Sarah Wilson",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    status: "Online",
    skill: "Data Science"
  };

  const messages = [
    { id: 1, sender: 'mentor', text: "Hi! How can I help you today?", time: "10:00 AM" },
    { id: 2, sender: 'user', text: "I'm interested in learning about machine learning algorithms.", time: "10:02 AM" },
    { id: 3, sender: 'mentor', text: "That's great! Let's start with the basics. What's your current knowledge level?", time: "10:05 AM" }
  ];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      // Handle sending message
      setMessage('');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden h-[calc(100vh-8rem)]">
        {/* Chat Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img
              src={mentor.image}
              alt={mentor.name}
              className="h-12 w-12 rounded-full object-cover"
            />
            <div>
              <h2 className="text-lg font-medium text-gray-900">{mentor.name}</h2>
              <div className="flex items-center">
                <div className="h-2 w-2 rounded-full bg-green-400 mr-2" />
                <span className="text-sm text-gray-500">{mentor.status}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-500 hover:text-indigo-600 rounded-full hover:bg-gray-100">
              <Phone className="h-5 w-5" />
            </button>
            <button className="p-2 text-gray-500 hover:text-indigo-600 rounded-full hover:bg-gray-100">
              <Video className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 h-[calc(100%-13rem)]">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[70%] rounded-lg px-4 py-2 ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                <p>{msg.text}</p>
                <p className={`text-xs mt-1 ${
                  msg.sender === 'user' ? 'text-indigo-200' : 'text-gray-500'
                }`}>
                  {msg.time}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <form onSubmit={handleSend} className="px-6 py-4 border-t border-gray-200">
          <div className="flex space-x-4">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <button
              type="submit"
              disabled={!message.trim()}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Chat;