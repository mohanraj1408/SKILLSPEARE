import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, MapPin } from 'lucide-react';
import SkillSelector from '../components/SkillSelector';

const BecomeMentor = () => {
  const navigate = useNavigate();
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [teachingMode, setTeachingMode] = useState<'online' | 'both'>('online');

  const handleSkillToggle = (skillId: string) => {
    setSelectedSkills(prev =>
      prev.includes(skillId)
        ? prev.filter(id => id !== skillId)
        : [...prev, skillId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/mentor-test');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-white shadow-lg rounded-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Become a Mentor</h1>
        
        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Your Skills</h2>
            <p className="text-gray-600 mb-4">Choose the skills you'd like to teach</p>
            <SkillSelector
              selectedSkills={selectedSkills}
              onSkillToggle={handleSkillToggle}
            />
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Teaching Mode</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setTeachingMode('online')}
                className={`p-4 rounded-lg border ${
                  teachingMode === 'online'
                    ? 'border-indigo-600 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-300'
                }`}
              >
                <Clock className="h-6 w-6 mb-2 text-indigo-600" />
                <h3 className="font-medium">Online Only</h3>
                <p className="text-sm text-gray-500">Teach remotely via video calls</p>
              </button>

              <button
                type="button"
                onClick={() => setTeachingMode('both')}
                className={`p-4 rounded-lg border ${
                  teachingMode === 'both'
                    ? 'border-indigo-600 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-300'
                }`}
              >
                <MapPin className="h-6 w-6 mb-2 text-indigo-600" />
                <h3 className="font-medium">Online & In-Person</h3>
                <p className="text-sm text-gray-500">Offer both remote and local sessions</p>
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={selectedSkills.length === 0}
            className="w-full bg-indigo-600 text-white py-3 px-6 rounded-md hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            Continue to Skill Assessment
          </button>
        </form>
      </div>
    </div>
  );
};

export default BecomeMentor;