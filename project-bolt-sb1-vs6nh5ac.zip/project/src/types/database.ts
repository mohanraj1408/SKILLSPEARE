export interface Profile {
  id: string;
  role: 'student' | 'mentor';
  full_name: string;
  avatar_url?: string;
  bio?: string;
  location?: string;
  created_at: string;
  updated_at: string;
}

export interface MentorProfile {
  id: string;
  hourly_rate: number;
  availability: {
    weekdays: boolean;
    weekends: boolean;
    hours: string[];
  };
  is_verified: boolean;
  teaching_mode: 'online' | 'both';
  total_students: number;
  created_at: string;
  updated_at: string;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  description?: string;
  created_at: string;
}

export interface MentorSkill {
  mentor_id: string;
  skill_id: string;
  proficiency_level: number;
  is_verified: boolean;
  created_at: string;
}

export interface Review {
  id: string;
  student_id: string;
  mentor_id: string;
  rating: number;
  comment?: string;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
}