import React from 'react';
import { Check } from 'lucide-react';

interface Skill {
  id: string;
  name: string;
  category: string;
}

interface SkillSelectorProps {
  selectedSkills: string[];
  onSkillToggle: (skillId: string) => void;
}

const skills: Skill[] = [
  { id: 'python', name: 'Python', category: 'Programming' },
  { id: 'react', name: 'React', category: 'Web Development' },
  { id: 'design', name: 'UI/UX Design', category: 'Design' },
  { id: 'marketing', name: 'Digital Marketing', category: 'Marketing' },
  { id: 'data', name: 'Data Analysis', category: 'Data Science' },
];

const SkillSelector: React.FC<SkillSelectorProps> = ({ selectedSkills, onSkillToggle }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {skills.map((skill) => (
        <button
          key={skill.id}
          onClick={() => onSkillToggle(skill.id)}
          className={`flex items-center justify-between p-4 rounded-lg border ${
            selectedSkills.includes(skill.id)
              ? 'border-indigo-600 bg-indigo-50'
              : 'border-gray-200 hover:border-indigo-300'
          }`}
        >
          <div>
            <p className="font-medium text-gray-900">{skill.name}</p>
            <p className="text-sm text-gray-500">{skill.category}</p>
          </div>
          {selectedSkills.includes(skill.id) && (
            <Check className="h-5 w-5 text-indigo-600" />
          )}
        </button>
      ))}
    </div>
  );
};

export default SkillSelector;