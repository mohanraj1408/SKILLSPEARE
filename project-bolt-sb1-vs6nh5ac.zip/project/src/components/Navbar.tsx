import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, MessageSquare, User } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { motion } from 'framer-motion';

const Navbar = () => {
  return (
    <nav className="bg-white dark:bg-gray-800 shadow-md dark-transition">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <motion.div 
            className="flex items-center"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link to="/" className="flex items-center space-x-2 group">
              <BookOpen className="h-8 w-8 text-primary-600 dark:text-primary-400 transition-transform group-hover:scale-110" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white">SKILLSPEARE</span>
            </Link>
          </motion.div>
          
          <motion.div 
            className="flex items-center space-x-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link to="/become-mentor" className="text-gray-700 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 px-3 py-2 rounded-md text-sm font-medium transition-colors">
              Become a Mentor
            </Link>
            <Link to="/messages" className="text-gray-700 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
              <MessageSquare className="h-6 w-6" />
            </Link>
            <Link to="/profile/me" className="text-gray-700 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
              <User className="h-6 w-6" />
            </Link>
            <ThemeToggle />
            <Link to="/signin" className="btn btn-primary">
              Sign In
            </Link>
          </motion.div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;